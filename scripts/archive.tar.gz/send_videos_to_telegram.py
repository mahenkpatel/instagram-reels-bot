import os
import requests
from time import sleep
from dotenv import load_dotenv

load_dotenv()

BOT_TOKEN = os.getenv("TELEGRAM_BOT_TOKEN")
CHAT_ID = os.getenv("TELEGRAM_CHAT_ID")
DOWNLOADS_FOLDER = "data/downloads"  # Updated to use the data folder

def send_video_to_telegram(filepath):
    url = f"https://api.telegram.org/bot{BOT_TOKEN}/sendVideo"
    with open(filepath, 'rb') as video:
        files = {'video': video}
        data = {'chat_id': CHAT_ID, 'caption': os.path.basename(filepath)}
        response = requests.post(url, data=data, files=files)

    if response.status_code == 200:
        print(f"✅ Sent: {os.path.basename(filepath)}")
        return True
    else:
        print(f"❌ Failed to send: {response.text}")
        return False

def send_all_videos():
    if not os.path.exists(DOWNLOADS_FOLDER):
        print(f"📁 '{DOWNLOADS_FOLDER}' folder does not exist.")
        return

    for file in os.listdir(DOWNLOADS_FOLDER):
        if file.lower().endswith(".mp4"):
            filepath = os.path.join(DOWNLOADS_FOLDER, file)
            if send_video_to_telegram(filepath):
                os.remove(filepath)
                sleep(2)

if __name__ == "__main__":
    send_all_videos()
